// Dynamically add content

const skills = ["HTML", "CSS", "JavaScript", "React", "Git"];

const projects = [

  { title: "Portfolio Website", description: "My own responsive portfolio." },

  { title: "Quiz App", description: "An interactive quiz using JavaScript." },

  { title: "Weather App", description: "Shows real-time weather data." }

];

window.onload = () => {

  // Set current year

  document.getElementById("year").textContent = new Date().getFullYear();

  // Populate skills

  const skillsList = document.getElementById("skills-list");

  skills.forEach(skill => {

    const li = document.createElement("li");

    li.textContent = skill;

    skillsList.appendChild(li);

  });

  // Populate projects

  const projectsContainer = document.getElementById("projects-container");

  projects.forEach(proj => {

    const div = document.createElement("div");

    div.innerHTML = `<h3>${proj.title}</h3><p>${proj.description}</p>`;

    projectsContainer.appendChild(div);

  });

  // Theme toggle

  document.getElementById("theme-toggle").addEventListener("click", () => {

    document.body.classList.toggle("dark");

  });

  // Contact form (fake submit)

  document.getElementById("contact-form").addEventListener("submit", e => {

    e.preventDefault();

    document.getElementById("form-response").textContent =

      "Thank you! Your message has been sent.";

    e.target.reset();

  });

};